//
//  main.swift
//  AppLifecycle
//
//  Created by Jan Brinkmann on 07/03/16.
//  Copyright © 2016 Jan Brinkmann. All rights reserved.
//

import UIKit

UIApplicationMain(Process.argc, Process.unsafeArgv, NSStringFromClass(CTApplication), NSStringFromClass(AppDelegate))