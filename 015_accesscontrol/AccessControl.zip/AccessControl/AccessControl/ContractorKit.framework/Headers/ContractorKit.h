//
//  ContractorKit.h
//  ContractorKit
//
//  Created by Jan Brinkmann on 12/02/16.
//  Copyright © 2016 Jan Brinkmann. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ContractorKit.
FOUNDATION_EXPORT double ContractorKitVersionNumber;

//! Project version string for ContractorKit.
FOUNDATION_EXPORT const unsigned char ContractorKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ContractorKit/PublicHeader.h>


